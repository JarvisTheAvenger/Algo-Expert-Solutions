import Foundation

func generateDocument(_ characters: String, _ document: String) -> Bool {
    let charArray = Array(characters)
    let docArray = Array(document)
    
    var dictionary = [Character:Int]()
    
    for char in charArray {
        if let count = dictionary[char] {
            dictionary[char] = count + 1
        } else {
            dictionary[char] = 1
        }
    }
    
    for char in docArray {
        
        if String(char) == "" {
            continue
        }
        
        if let count = dictionary[char] {
            if count - 1 >= 0 {
                dictionary[char] = count - 1
            } else {
                return false
            }
        } else {
            return false
        }
    }
    
    return true
}

//2,2,2
//1,2,2
//0,2,2
//0,1,2
//0,0,2
//0,0,1
//0,0,0
generateDocument("helloworldO", "hello wOrld")
